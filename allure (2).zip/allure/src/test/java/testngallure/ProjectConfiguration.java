package testngallure;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class ProjectConfiguration {
	
	
	
	public Properties loadProperites() throws Exception{
	Properties pro = new Properties();
	String filePath = "C:\\Users\\admin\\eclipse-workspace\\allure\\config\\config.properties";
	System.out.println("Printing the file path from loadProperties method "+filePath);
	File src = new File(filePath);
	FileInputStream fis = new FileInputStream(src);
	pro.load(fis);
	return pro;
}
	
	
	public static int takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception{

        //Convert web driver object to TakeScreenshot

        TakesScreenshot scrShot =((TakesScreenshot)webdriver);

        //Call getScreenshotAs method to create image file

                File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

            //Move image file to new destination

                File DestFile=new File(fileWithPath);

                //Copy file at destination}
                FileUtils.copyFile(SrcFile, DestFile);
				//return null;
				return 0;
				
                
                
                
	}        
                
}
