package testngallure;
import java.io.ByteArrayInputStream;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import io.qameta.allure.Allure;
import io.qameta.allure.AllureLifecycle;
import io.qameta.allure.Attachment;
import io.qameta.allure.Step;

public class OpenMRSPage {
	
	WebDriver driver;
	public OpenMRSPage(WebDriver driver)
	{
		this.driver = driver;
	}
	@Attachment(value = "Screenshot", type = "image/png")
	public byte[] screenshot() {
	    return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
	}
	@Step("#1 Enter username and password and select InpatientWard")
	public void login() throws Exception
	{driver.get("http://total-qa.com/advanced-selenium/allure-reporting/");
	//String Screenshot=ProjectConfiguration.takeSnapShot(driver, "C:\\\\Users\\\\admin\\\\eclipse-workspace\\\\allure\\\\target\\\\t.png");
	Allure.addAttachment("Custom Log 1", "text/plain", "url opened");
	//byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
	//Allure.addAttachment("screenshot","image/png",screenshot);
	Allure.addAttachment("Any text", new ByteArrayInputStream(((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES)));
    Allure.addAttachment("Custom Log 2", "text/plain", "urlshowed");
		/*
		 * driver.findElement(By.id("username")).sendKeys("Admin");
		 * driver.findElement(By.id("password")).sendKeys("Admin123");
		 * driver.findElement(By.id("Inpatient Ward")).click();
		 * driver.findElement(By.id("loginButton")).click();
		 */
	}
	
	
        // Your test logic here
	@Step ("#2 Navigate to Schedule Appointment Page")
	public void navigatetoAppoinmentPage()
	{
		driver.get("http://total-qa.com/advanced-selenium/allure-reporting/");
		
		//driver.findElement(By.xpath("/html[1]/body[1]/div[1]/header[1]/div[1]/div[1]/a[1]/img[1]")).click();
	}
	@Step ("#3 Click on Manage Service Types")
	public void clickOnManageServiceTypes()
	{
		//driver.findElement(By.id("/html[1]/body[1]/div[1]/header[1]/nav[1]/div[1]/ul[1]/li[8]/a[1]")).click();
	}
	@Step("#4 Fetch the first row contents of the manage service types")
	public void fetchTableRowContents() throws InterruptedException
	{
		driver.get("https://www.nyse.com/ipo-center/filings");Thread.sleep(5000);
//		WebElement e = null ;
//				String p = e.getText();
//		System.out.println("Output of the table content" + p);
//		return p;
	}
	
	
      

}
