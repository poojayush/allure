package testngallure;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.qameta.allure.Step;

public class OpenMRSPage {
	
	WebDriver driver;
	public OpenMRSPage(WebDriver driver)
	{
		this.driver = driver;
	}
	@Step("#1 Enter username and password and select InpatientWard")
	public void login()
	{driver.get("http://total-qa.com/advanced-selenium/allure-reporting/");
		/*
		 * driver.findElement(By.id("username")).sendKeys("Admin");
		 * driver.findElement(By.id("password")).sendKeys("Admin123");
		 * driver.findElement(By.id("Inpatient Ward")).click();
		 * driver.findElement(By.id("loginButton")).click();
		 */
	}
	@Step ("#2 Navigate to Schedule Appointment Page")
	public void navigatetoAppoinmentPage()
	{
		driver.get("http://total-qa.com/advanced-selenium/allure-reporting/");
		//driver.findElement(By.xpath("/html[1]/body[1]/div[1]/header[1]/div[1]/div[1]/a[1]/img[1]")).click();
	}
	@Step ("#3 Click on Manage Service Types")
	public void clickOnManageServiceTypes()
	{
		//driver.findElement(By.id("/html[1]/body[1]/div[1]/header[1]/nav[1]/div[1]/ul[1]/li[8]/a[1]")).click();
	}
	@Step("#4 Fetch the first row contents of the manage service types")
	public void fetchTableRowContents() throws InterruptedException
	{
		driver.get("https://www.nyse.com/ipo-center/filings");Thread.sleep(5000);
//		WebElement e = null ;
//				String p = e.getText();
//		System.out.println("Output of the table content" + p);
//		return p;
	}

}
